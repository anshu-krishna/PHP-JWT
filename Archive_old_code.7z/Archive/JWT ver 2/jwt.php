<?php
class JWT {
	const ERR_DEV = 0;
	const ERR_AUTH = 1;

	public static function encode64(string $str) {
		return rtrim(strtr(base64_encode($str), '+/', '-_'), '=');
	}

	public static function decode64(string $str) {
		return base64_decode(strtr($str, '-_', '+/'));
	}

	private static function get_val(string $type, array &$arr, ...$subkeys) {
		$val = $arr;
		foreach($subkeys as $key) {
			if(is_array($val) && array_key_exists($key, $val)) {
				$val = $val[$key];
			} else {
				return NULL;
			}
		}
		if($type !== "") {
			settype($val, $type);
		}
		return $val;
	}

	private static function sign($algo, string $key, string $header_str, string $payload_str, &$error) {
		$error = NULL;
		$signature = "";
		switch($algo) {
			case "HS256":
			case "HS384":
			case "HS512":
				$algo = "sha256";
				switch($algo) {
					case "HS384":
						$algo = "sha384";
						break;
					case "HS512":
						$algo = "sha512";
						break;
				}
				$signature = hash_hmac($algo, "{$header_str}.{$payload_str}", $key, TRUE);
				break;
			default:
				$error = ["JWT: algorithm not supported", JWT::ERR_AUTH];
				return NULL;
				break;
		}
		$signature = JWT::encode64($signature);
		return [
			"header" => $header_str,
			"payload" => $payload_str,
			"signature" => $signature
		];
	}
	private $settings = NULL,
		$token = NULL;
	
	// public function __construct() {
	// }
	public function load_settings() {
		if($this->settings !== NULL) return;
		$file = getcwd() . "/jwt_config.php";
		if(!is_readable($file)) {
			$this->error = ["Authorization settings file is missing", JWT::ERR_DEV];
			return;
		}
		$settings = include($file);
		if($settings === FALSE) {
			$this->error = ["Authorization settings is invalid", JWT::ERR_DEV];
			return;
		}
		$this->settings = $settings;
	}
	public function get_key($alg, $kid = NULL) {
		$this->load_settings();
		if($this->settings === NULL) {
			return NULL;
		}
		switch($alg) {
			case "HS256":
			case "HS384":
			case "HS512":
				$key = JWT::get_val("", $this->settings, "keys", $alg);
				if($key === NULL) {
					$this->error = ["JWT: Algorithm key not found", JWT::ERR_AUTH];
					return NULL;
				}
				if($kid !== NULL) {
					if(!is_array($key) || !array_key_exists($kid, $key)) {
						$this->error = ["JWT: Algorithm key/id not found", JWT::ERR_AUTH];
						return NULL;
					}
					$key = $key[$kid];
				}
				if(is_array($key)) {
					$kids = array_keys($key);
					$kid = array_rand($kids);
					$key = $key[$kid];
				}
				return ["key" => $key, "kid" => $kid];
				break;
			default:
				$this->error = ["JWT: Algorithm not supported", JWT::ERR_AUTH];
				return NULL;
				break;
		}
	}
	public function create_new_token(string $algo, array $payload = NULL, array $dont_use_standard_claims = NULL) {
		$this->load_settings();
		if($this->settings === NULL) {
			return;
		}
		$this->token = ["header" => [
			"alg" => $algo,
			"typ" => "JWT"
		], "payload" => []];
		
		$pl = &$this->token["payload"];

		$pl["iat"] = time();
		$pl["nbf"] = $pl["iat"];

		$val = JWT::get_val("int", $this->settings, "exp");
		$val = ($val === NULL) ? 1200 : $val;
		
		$pl["exp"] = $pl["iat"] + $val;

		$val = JWT::get_val("string", $this->settings, "iss");
		if($val !== NULL) {
			$pl["iss"] = $val;
		}

		$val = JWT::get_val("string", $this->settings, "aud");
		if($val !== NULL) {
			$pl["aud"] = $val;
		}

		if($dont_use_standard_claims !== NULL) {
			foreach($dont_use_standard_claims as $claim) {
				unset($pl[$claim]);
			}
		}

		if($payload !== NULL) {
			$pl = array_merge($pl, $payload);
		}
	}
	public function get_token_string($key_str = NULL) {
		$this->load_settings();
		if($this->settings === NULL || $this->token === NULL) {
			if($this->error === NULL) {
				$this->error = ["JWT: token is NULL, can't convert it to string", JWT::ERR_DEV];
			}
			return NULL;
		}
		if($key_str === NULL) {
			$key = $this->get_key(JWT::get_val("string", $this->token, "header", "alg"), JWT::get_val("", $this->token, "payload", "kid"));
			if($key === NULL) {
				return NULL;
			}
			if($key["kid"] !== NULL) {
				$this->token["payload"]["kid"] = $key["kid"];
			}
			$key_str = $key["key"];
		}
		$header_str = JWT::encode64(json_encode($this->token["header"]));
		$payload_str = JWT::encode64(json_encode($this->token["payload"]));
		$algo = JWT::get_val("string", $this->token, "header", "alg");

		$sign = JWT::sign($algo, $key_str, $header_str, $payload_str, $error);
		if($error !== NULL) {
			$this->error = $error;
			return NULL;
		}
		return "{$sign["header"]}.{$sign["payload"]}.{$sign["signature"]}";
	}
	public function load_token_from_header() {
		$headers = getallheaders();
		if(!array_key_exists("Authorization", $headers)) {
			$this->error = ["JWT: no token found in request header", JWT::ERR_AUTH];
			return FALSE;
		}
		preg_match("/^Bearer\s([a-z0-9_.-]+)$/i", $headers["Authorization"], $tok);
		if(count($tok) != 2) {
			$this->error = ["JWT: token is not in JWT format", JWT::ERR_AUTH];
			return FALSE;
		}
		return $this->load_token($tok[1]);
	}
	public function load_token(string $token_string) {
		$default_error = ["JWT: token is not in JWT format", JWT::ERR_AUTH];
		
		$token_string = explode(".", $token_string);
		if(count($token_string) != 3) {
			$this->error = $default_error;
			return FALSE;
		}
		$token_string = [
			"header" => $token_string[0],
			"payload" => $token_string[1],
			"signature" => $token_string[2]
		];
		$token = [];
		foreach($token_string as $key => $t) {
			$token[$key] = JWT::decode64($t);
			if($token[$key] === FALSE) {
				$this->error = $default_error;
				return FALSE;
			}
		}
		$token["header"] = json_decode($token["header"], TRUE);
		$token["payload"] = json_decode($token["payload"], TRUE);
		if($token["header"] === NULL || $token["payload"] === NULL) {
			$this->error = $default_error;
			return FALSE;
		}
		$key = $this->get_key(JWT::get_val("string", $token, "header", "alg"), JWT::get_val("", $token, "payload", "kid"));
		if($key === NULL) {
			return FALSE;
		}
		$sign = JWT::sign(JWT::get_val("", $token, "header", "alg"), $key["key"], $token_string["header"], $token_string["payload"], $error);
		if($sign === NULL) {
			$this->error = $error;
			return FALSE;
		}
		if(hash_equals($token_string["signature"], $sign["signature"]) === FALSE) {
			$this->error = ["JWT: invalid token", JWT::ERR_AUTH];
			return FALSE;
		}
		$this->token = TRUE;
		// $this->token = $token;
		return TRUE;
	}
}
?>