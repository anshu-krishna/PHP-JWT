<?php
require_once "script_caller.php";
require_once "jwt.php";

function dump($obj, $msg = NULL) {
	if($msg !== NULL) {
		// echo "<strong>", $msg, "</strong>";
		echo "<table border=\"1\">
	<tr>
		<th style=\"vertical-align: top; padding: 10px;\">", $msg, "</th>
		<td style=\"padding: 10px;\"><pre>";
		//echo print_r($obj, TRUE);
		var_dump($obj);
		echo "</pre></td>
	</tr>
</table>";
	} else {
		echo "<pre style=\"padding: 10px; border: 1px solid;\">", print_r($obj, TRUE) ,"</pre>";
	}
}
function spacer() {
	echo "<br /><br />";
}
/**********************************************************************************/
echo  call_script("GET", "verify_tester.php", NULL);
/**********************************************************************************/
spacer();
echo  call_script("GET", "verify_tester.php", NULL, ["Authorization" => "Bearer testToken"]);
/**********************************************************************************/
spacer();
echo  call_script("GET", "verify_tester.php", NULL, ["Authorization" => "Bearer 25.26.27"]);
/**********************************************************************************/
spacer();
echo  call_script("GET", "verify_tester.php", NULL, ["Authorization" => "Bearer " . implode(".", [
	'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9',
	'eyJpYXQiOjE1MzY2MzAyOTAsIm5iZiI6MTUzNjYzMDI5MCwiZXhwIjoxNTM2NjMwODkwLCJpc3MiOiJ0b2tlbi50ZXN0LmNvbSIsImF1ZCI6ImFwcC50b2tlbi5jb20ifQ',
	'RehIhDCIYxm7bRmHPOjwp3dm8c7yNEINqg0EM4v1ZT0'
])]);
/**********************************************************************************/
spacer();
$jwt = new JWT();
$jwt->create_new_token("HS256", [
	"name" => "Anshu"
], ["aud", "iss"]);
$token = $jwt->get_token_string();
// dump($token, "Token String");
dump($jwt, "Create Token");
if($token !== NULL) {
	echo  call_script("GET", "verify_tester.php", NULL, ["Authorization" => "Bearer {$token}"]);
}
/**********************************************************************************/
spacer();
$jwt = new JWT();
$jwt->create_new_token("HS256", [
	"name" => "Krishna",
	"kid" => 1
]);
$token = $jwt->get_token_string();
// dump($token, "Token String");
dump($jwt, "Create Token");
if($token !== NULL) {
	echo  call_script("GET", "verify_tester.php", NULL, ["Authorization" => "Bearer {$token}"]);
}
/**********************************************************************************/
spacer();
$jwt = new JWT();
$jwt->create_new_token("HS256");
$token = $jwt->get_token_string();
// dump($token, "Token String");
dump($jwt, "Create Token");
if($token !== NULL) {
	echo  call_script("GET", "verify_tester.php", NULL, ["Authorization" => "Bearer {$token}"]);
}
/**********************************************************************************/
spacer();
$jwt = new JWT();
$jwt->create_new_token("HS512");
$token = $jwt->get_token_string();
// dump($token, "Token String");
dump($jwt, "Create Token");
if($token !== NULL) {
	echo  call_script("GET", "verify_tester.php", NULL, ["Authorization" => "Bearer {$token}"]);
}
/**********************************************************************************/
?>