<?php
function dump($obj, $msg = NULL) {
	if($msg !== NULL) {
		// echo "<strong>", $msg, "</strong>";
		echo "<table border=\"1\">
	<tr>
		<th style=\"vertical-align: top; padding: 10px;\">", $msg, "</th>
		<td style=\"padding: 10px;\"><pre>";
		//echo print_r($obj, TRUE);
		var_dump($obj);
		echo "</pre></td>
	</tr>
</table>";
	} else {
		echo "<pre style=\"padding: 10px; border: 1px solid;\">", print_r($obj, TRUE) ,"</pre>";
	}
}

require_once "jwt.php";
$jwt = new JWT();
$jwt->load_token_from_header();
dump($jwt, "Verify JWT");
?>