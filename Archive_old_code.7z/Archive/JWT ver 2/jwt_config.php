<?php
return [
	"keys" => [
		"HS256" => [
			'C*F-JaNdRgUkXp2s5v8y/B?D(G+KbPeS',
			'!z$C&F)J@NcRfUjXn2r5u8x/A?D*G-Ka'
		],
		"HS512" => 'VkYp3s6v8y/B?E(H+MbQeThWmZq4t7w!z$C&F)J@NcRfUjXn2r5u8x/A?D*G-KaP'
	],
	"iss" => "token.test.com",
	"aud" => "app.token.com",
	/* exp is in seconds since iat */
	"exp" => 600,
	/* leeway is in seconds */
	"leeway" => 30
];
?>