<style type="text/css">
	div.cntr {
		display: grid;
		grid-template-columns: auto 1fr auto auto;
		/* grid-template-columns: auto 1fr; */
		border: 1px solid;
		align-items: center;
		margin: 5px;
	}
	pre.cntr {
		display: block;
		border: 1px solid #99f;
		white-space: pre-wrap;
		box-sizing: border-box;
		padding: 5px;
		height: 100%;
		max-width: 100%;
		white-space: pre-wrap;
		word-break: break-all;
	}
	div.cntr > span {
		border: 1px solid #99f;
		font-weight: bold;
		height: 100%;
		padding: 10px;
		box-sizing: border-box;
	}
</style>
<?php
function objToString($object) {
	if($object === NULL) {
		return 'NULL';
	} elseif ($object === FALSE) {
		return 'FALSE';
	} elseif ($object === TRUE) {
		return 'TRUE';
	} else {
		return print_r($object, TRUE);
	}
}
function echoTestResult($msg, $obj, $error, $second_col_name = "Error") {
	echo "<div class=\"cntr\"><span>{$msg}</span><pre class=\"cntr\">";
	// var_dump($obj);
	echo objToString($obj);
	echo "</pre><span>{$second_col_name}</span><pre class=\"cntr\">";
	// var_dump($error);
	echo objToString($error);
	echo "</pre></div>";
}


require_once "jwt.php";

$key_HS256 = 'aNdRgUkXp2r5u8x/A?D(G+KbPeShVmYq';
$key_HS512 = 'UkXp2s5v8x/A?D(G+KbPeShVmYq3t6w9z$B&E)H@McQfTjWnZr4u7x!A%D*F-JaN';

$key_RS256 = [
	"private" => '-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEApTn3JeKv/hlJWPiUPJMn8AY/KZp+aRXfd1TZJKWXhIfioIW/
Xs9R88rGFp3NO3HBLUUPUNzbPM7aSIZx3XGjs3If/wb3C+KFfXVDCeM/h3Yu39v8
zoNTXRcezM+ZmHujLGThuzoeONZzTJEZ0o8tzFB9Ln0ub74n3SgqTiSnE9PwqW8B
O5lqAqTAocxLfbaxgrVsBT93fmB9/vlFei1aYfA7JYnuSvSGp4mKSpL4q/rifgWs
Ac3FnrkGz2hB8tbQJOpX48Usjgnfx10WFQ8Sz1E2Q8zOWGdsOI9t0jYL7Wqep0Oo
6PiFUtZcGLHiwJ+7H/tqelDni2Jtc/EPLER8DQIDAQABAoIBAQCEBK3aoqd2w6Oc
qHphcD9wBL3BM0WgF68HfU9Hfdx0M9M76cJAMi1MO5BNj+blgX4V+uFC/kVa7/jw
DCS9CMkBX8X7EwiggW2iEejv5JjlVuQbUH5OUBZzAj9E7PfQI7H8jdrjq4tsZMWZ
vzK/0FGKuCFd3P4WoPzfM/GhoJ2zM9IkcQn3BA/pR9+/QaNCYC5yLmoQ8esyQxMm
JL1mQe5tUEz+xr4RMvlAXYJTL3ytI6Kycda8v3sMDoUbi0VX6jcu1pwxcP1MzbyQ
FoTykjEiXxwy8m2JxRi7T6fUokADsMuASiPCFgxXKhvI4Vov0iNj7a5xT6J8aE/y
sLWIdDLNAoGBAOJKarBvhldE0mL2w8G0NcGe/VLTfB8yx+6lDooNITYNoyS1MXTa
xpi5KCG5dHpTHt8s2KOgZBJ9pJfQSGc0jHvLEC6CpLHZ9EHyME+Nl7YU/hMqPZcc
5xOBuUFCskHonZFnfQZH96j+Vv8UPpv/EWLo+/5JTVtbE9ofIOgwz8X3AoGBALrr
MQG2HnMga1mKlbLeCMguZUlWT7/bodd6nQ6MshZraWCdm2b7wNvj1ixUPEMLGiZg
/4q7SWzUwjLsVIbK58+JqRBLf4Nhy++r44+tQ/aVjOAfn5I4mWYkQocjXr+rZrCf
EITV8Jf6sFMVXqA9NzYOhflkwtJHVsCvMDwil30bAoGBAMKdM5JX59an9rRr+0Fd
JhpGDSGthoMiXjZMt+tcjWJ6agOI3WbdPI1eODiA0b7eO5++ZvaaW1ZXvjVeSNaR
p/xTULBfZRscEmigzJGueXp8JWMAIgYTMlxhZZzNqpbqYpEJysmbHVC2pMUteQca
X66MJySzkBbwhmtB+EAYsqhTAoGBAIhikbiI9QDV195W01HW1puR1s/DDZ+VFyrN
yYlTOaJIL3SSq1BiQ19uh9iCghH9KNB2GB9W9oVVXHmhnS9ZH/l7nYNJQzpPAmnX
hsxQBXYHuunRyTH84Fj5/hzyvvCllOEsvvXd0JZkEYId5pSO9hkYUcMeNVUPPoqL
iWtnZhefAoGAUIzacPFtuVuxHQcATfi03vTNAGv7qhKIMOwTvn2jdIDR7LymojFM
WPQHf3gPiHLWYCRhcEKJiB7iBjX7jDhK8ffMxcCMS2tmZSej7VPegOmSFy4x48zF
LqcQtXFJDk38uasc7ytVJoWNwbNlUrQy/lo23cH4g+LTnEL1yFkxo/I=
-----END RSA PRIVATE KEY-----',
	"public" => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApTn3JeKv/hlJWPiUPJMn
8AY/KZp+aRXfd1TZJKWXhIfioIW/Xs9R88rGFp3NO3HBLUUPUNzbPM7aSIZx3XGj
s3If/wb3C+KFfXVDCeM/h3Yu39v8zoNTXRcezM+ZmHujLGThuzoeONZzTJEZ0o8t
zFB9Ln0ub74n3SgqTiSnE9PwqW8BO5lqAqTAocxLfbaxgrVsBT93fmB9/vlFei1a
YfA7JYnuSvSGp4mKSpL4q/rifgWsAc3FnrkGz2hB8tbQJOpX48Usjgnfx10WFQ8S
z1E2Q8zOWGdsOI9t0jYL7Wqep0Oo6PiFUtZcGLHiwJ+7H/tqelDni2Jtc/EPLER8
DQIDAQAB
-----END PUBLIC KEY-----'];
$key_RS512 = [
	"private" => '-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAoMya46u4H2bPhPLnbP781eUf1cGavB4PdZNT5GDkvlYPdZxt
niO18xh5RvOqT6lJMfwI0aqqJdJ1U+aB80Pqhd2DynllQYPwrCaRWu8yg4GMFRMM
wOQjCzhHCmdOWFI9tjj6Dnm4yZC0ygIsNkHZ2P99tWNwQTsIINrQ9G6U9PeQrMLl
1lYajihbRnlbUlysaTfC5Jl17ixDpUKI2tM0Lhy1OPw8alANp/xsR+gm7fT20Cpb
7FJTAevaU30ZgZtqmAPn+KvTEKwiPPL3jmxPrREonKwOID2LHvmUYRl525NG9ERu
wko1j6ebkCa5ZHV2zjjphEid+CjONVo89yLlkwIDAQABAoIBAErjP3es79FgFmG6
puFyV9peHVd2FVRrQ5Pki3ufTKkAd660rbCqvQB8c28B6F21X6txz8GmFBwNSitK
/VaIWN8DbW+M3gWHJz1lsOiC4imw2cau2o+zMEb3bM6BklE77BXDr2GyescVJ721
CVYzkPuo8ajaqNsYXQ7AGfTc027KY69UDC65Oo5PxPyp6Jm5bVksWCW3MVY9WFkA
9hV64JD9aKMyzxc742nWIj9zNTiZnJvYaol6fLu0ZK3qJAPQRzRx49VoLu4NpoG5
QMzhEHGI2ta7aF9iRNBpyR5knm/R46hn926H45rJdHE4CBNODtzoa57M0lF1RFXN
6EWH24ECgYEA/onYAD4xuT6wVc0bIXVyxGn3smmZbxPjzxa8jeAF52ttylwapgN5
HZZU8S7TdeumRl9DKGaNkXEuWQP63H9KlUsSLc9DUs1S3hT4U+S7Wd1rXxGnqC8v
28FivgFeyPIgEbhpZCAwue+rYlgJSbmChsv7Ehennp+p0p3Z0AIkv2ECgYEAobj4
Y0xO6QW1FmVunwSaRHAYyJVO+hM1/4Qg+GSGfjr+A3/4ZhcIotLJP279M3wiuqlT
LWaPEzTn12m4ifSTIqjpRTa+eA7n5cULG5WuGO64a8I4jvudvsagvQridQWyL1Oc
pASF3Rj5Dz43j3pzswqEfhJTltYgOUfNeLiJDXMCgYEAwGhqgySAactdeD5m98/U
RWzk9FSmyzR5zB0fww9I5zpp78HX0w5lC1yMMRR4fHb5ZdC072E2Om8X3eoIQ41l
T51DzKUT+w+CSKYJYUFR7ghWFbM+zP9+aduxTHe0sql0XHDOGgXLT4JAR0LNIpG8
fTDMRUzkRB/lO3RfJcG5DYECgYAnlWeunlneLVhyn+cgovbDc5CNYAZRrWwVG5ka
UzicIwJThvocutyRRfiePyNYe7TgbVt/jE/Oyq9IiYbytVtiK2fVWh3qsvNNyRn7
6XoQfjXDomlHjgzBSkrDmqttKzS+4r8/YiAFyvwDIB5nTviMxTFCzmeJTuXaP1nq
h3h8QwKBgBnQUojul1+jnQ/GsCmfpePyxh7HH1JSTDB+jY2AhFaokpMMvtIknb37
rj0i6lsYe4SiDIWdbbHKvDQlIXb6kOHdgD6c6/pvhUExfz7h5JQAoLHeroGh1EEb
JfeXrpW9tM8hUJz3KXKRuioV4dlarnSE/8ciWXkgrKx7VWCw3yJ2
-----END RSA PRIVATE KEY-----',
	"public" => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoMya46u4H2bPhPLnbP78
1eUf1cGavB4PdZNT5GDkvlYPdZxtniO18xh5RvOqT6lJMfwI0aqqJdJ1U+aB80Pq
hd2DynllQYPwrCaRWu8yg4GMFRMMwOQjCzhHCmdOWFI9tjj6Dnm4yZC0ygIsNkHZ
2P99tWNwQTsIINrQ9G6U9PeQrMLl1lYajihbRnlbUlysaTfC5Jl17ixDpUKI2tM0
Lhy1OPw8alANp/xsR+gm7fT20Cpb7FJTAevaU30ZgZtqmAPn+KvTEKwiPPL3jmxP
rREonKwOID2LHvmUYRl525NG9ERuwko1j6ebkCa5ZHV2zjjphEid+CjONVo89yLl
kwIDAQAB
-----END PUBLIC KEY-----'
];

function header_encoded(string $algo) {
	$header = [
		"alg" => $algo,
		"typ" => "JWT"
	];
	return JWT::encode64(json_encode($header));
}

$now  = time();
$payload = [
	"iss" => "token.friend.com",
	"aud" => "app.token.com",
	"iat" => $now,
	"nbf" => $now,
	"exp" => $now + 600,
	"name" => "Anshu Krishna"
];

$settings = [
	"mandatory_claims" => ["iss", "iat", "nbf"], // these claims must always be present
	"iss" => "token.test.com", // used when issuing token
	"authorized_iss" => ["token.test.com", "token.friend.com"], // list of valid issuer
	"aud" => "app.token.com", // exp is in seconds
	"exp" => 600, //leeway is in seconds
	"leeway" => 30
];
$error = NULL;
echoTestResult("Payload", json_encode($payload, JSON_PRETTY_PRINT), $error);

$payload_encoded = JWT::encode64(json_encode($payload));
/*****************************************************************************************/
$error = NULL;
$std_claims_verified = JWT::verify_std_claims($payload, $settings, $error);
echoTestResult("Verify Std Claims", $std_claims_verified, $error);
/*****************************************************************************************/
$error = NULL;
$sign_HS256 = JWT::calc_sig("HS256", $key_HS256, header_encoded('HS256'), $payload_encoded, $error);
echoTestResult("Signature HS256", $sign_HS256, $error);
$error = NULL;
$verify_HS256 = JWT::verify_sig("HS256", $key_HS256, header_encoded('HS256'), $payload_encoded, $sign_HS256, $error);
echoTestResult("Verify Signature HS256", $verify_HS256, $error);
/*****************************************************************************************/
$error = NULL;
$sign_HS512 = JWT::calc_sig("HS512", $key_HS512, header_encoded('HS512'), $payload_encoded, $error);
echoTestResult("Signature HS512", $sign_HS512, $error);
$error = NULL;
$verify_HS512 = JWT::verify_sig("HS512", $key_HS512, header_encoded('HS512'), $payload_encoded, $sign_HS512, $error);
echoTestResult("Verify Signature HS512", $verify_HS512, $error);
/*****************************************************************************************/
$error = NULL;
$sign_RS256 = JWT::calc_sig("RS256", $key_RS256["private"], header_encoded('RS256'), $payload_encoded, $error);
echoTestResult("Signature RS256", $sign_RS256, $error);
$error = NULL;
$verify_RS256 = JWT::verify_sig("RS256", $key_RS256["public"], header_encoded('RS256'), $payload_encoded, $sign_RS256, $error);
echoTestResult("Verify Signature RS256", $verify_RS256, $error);
/*****************************************************************************************/
$error = NULL;
$sign_RS512 = JWT::calc_sig("RS512", $key_RS512["private"], header_encoded('RS512'), $payload_encoded, $error);
echoTestResult("Signature RS512", $sign_RS512, $error);
$error = NULL;
$verify_RS512 = JWT::verify_sig("RS512", $key_RS512["public"], header_encoded('RS512'), $payload_encoded, $sign_RS512, $error);
echoTestResult("Verify Signature RS512", $verify_RS512, $error);
/*****************************************************************************************/
$error = NULL;
$token_HS512 = JWT::generate_token("HS512", $key_HS512, $payload, $error);
echoTestResult("Token HS512",  $token_HS512, $error);
/*****************************************************************************************/
$error = NULL;
$token_RS256 = JWT::generate_token("RS256", $key_RS256["private"], $payload, $error);
echoTestResult("Token HS256",  $token_RS256, $error);
/*****************************************************************************************/
?>