<?php
require_once "script_caller.php";
// require_once "jwt.php";
// echo  call_script("GET", "jwt.php", NULL);

// echo  call_script("GET", "jwt.php", NULL, ["Authorization" => "Bearer testToken"]);

// echo  call_script("GET", "jwt.php", NULL, ["Authorization" => "Bearer 25.26.27"]);

echo  call_script("GET", "jwt.php", NULL, ["Authorization" => "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiQW5zaHUgS3Jpc2huYSIsImlhdCI6MTUxNjIzOTAyMiwia2lkIjowfQ._g78eA-BR7O0ud0-Q4dpeiM2BsA8Cw21YuchNMDkH0s"]);

?>