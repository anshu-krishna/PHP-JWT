<?php
class JWT {
	const ERR_DEV = 0;
	const ERR_AUTH = 1;

	public static function base64url_encode(string $str) {
		return rtrim(strtr(base64_encode($str), '+/', '-_'), '=');
	}
	public static function base64url_decode(string $str) {
		return base64_decode(strtr($str, '-_', '+/'));
	}
	private static function get_val(array &$arr, ...$subkeys) {
		$val = $arr;
		foreach($subkeys as $key) {
			if(is_array($val) && array_key_exists($key, $val)) {
				$val = $val[$key];
			} else {
				return NULL;
			}
		}
		return $val;
	}
	private static function array_keys_missing(array &$arr, ...$keys) {
		foreach($keys as $key) {
			if(array_key_exists($key, $arr) === FALSE) {
				return TRUE;
			}
		}
		return FALSE;
	}
	private $token_string = NULL,
		$token = NULL,
		$settings = NULL;
	public $error  = NULL;
	public function __construct() {
		// $this->load_token();
		// $this->load_settings();
	}
	private function load_token() {
		if($this->token !== NULL) {
			return;
		}
		$headers = getallheaders();
		if(!array_key_exists("Authorization", $headers)) {
			$this->error = ["No authorization token in the request header", JWT::ERR_AUTH];
			return;
		}
		preg_match("/^Bearer\s([a-z0-9_.-]+)$/i", $headers["Authorization"], $tok);
		if(count($tok) != 2) {
			$this->error = ["Authorization token is not in JWT format", JWT::ERR_AUTH];
			return;
		}
		$tok = explode(".", $tok[1]);
		if(count($tok) != 3) {
			$this->error = ["Authorization token is not in JWT format", JWT::ERR_AUTH];
			return;
		}
		$this->token_string = ["header" => $tok[0], "payload" => $tok[1], "signature" => $tok[2]];

		foreach($tok as &$t) {
			$t = JWT::base64url_decode($t);
			if($t === FALSE) {
				$this->error = ["Authorization token is not in JWT format", JWT::ERR_AUTH];
				return;
			}
		}

		$tok[0] = json_decode($tok[0], TRUE);
		$tok[1] = json_decode($tok[1], TRUE);
		if($tok[0] === NULL || $tok[1] === NULL) {
			$this->error = ["Authorization token is not in JWT format", JWT::ERR_AUTH];
			return;
		}

		$this->token = ["header" => $tok[0], "payload" => $tok[1], "signature" => $tok[2]];
	}
	private function load_settings() {
		if($this->settings !== NULL) {
			return;
		}
		$file = getcwd() . "/jwt_config.php";
		if(!is_readable($file)) {
			$this->error = ["Authorization settings file is missing", JWT::ERR_DEV];
			return;
		}
		$settings = include($file);
		if($settings === FALSE) {
			$this->error = ["Authorization settings is invalid", JWT::ERR_DEV];
			return;
		}
		$this->settings = $settings;
	}
	private static function verify_standard_claims(&$settings, &$token) {
		$now = time();
		$s_leeway = JWT::get_val($settings, "leeway");
		$s_leeway = ($s_leeway === NULL) ? 0 : intval($s_leeway);
		$now_plus = $now + $s_leeway;
		$now_minus = $now - $s_leeway;

		$t_exp = JWT::get_val($token, "payload", "exp");
		if($t_exp !== NULL) {
			$t_exp = intval($t_exp);
			if($t_exp >= $now_plus) {
				return ["Authorization token has expired", JWT::ERR_AUTH];
			}
		}

		$t_nbf = JWT::get_val($token, "payload", "nbf");
		if($t_nbf !== NULL) {
			$t_nbf = intval($t_nbf);
			if($t_nbf <= $now_minus) {
				return ["Authorization token is not yet active", JWT::ERR_AUTH];
			}
		}
		
		$t_iat = JWT::get_val($token, "payload", "iat");
		if($t_iat !== NULL) {
			$t_iat = intval($t_iat);
			if($t_iat >= $now_plus) {
				return ["Authorization token is from future!!!", JWT::ERR_AUTH];
			}
		}

		$t_aud = JWT::get_val($token, "payload", "aud");
		if($t_aud !== NULL) {
			$s_aud = JWT::get_val($settings, "aud");
			if($s_aud === NULL) {
				return ["Authorization token is not for this audience", JWT::ERR_AUTH];
			}
			if(!(
				(is_array($t_aud) && in_array($s_aud, $t_aud))
				|| $t_aud === $s_aud
			)) {
				return ["Authorization token is not for this audience", JWT::ERR_AUTH];
			}
		}

		// var_dump([
		// 	"now" => $now,
		// 	"iat" => $t_iat,
		// 	"exp" => $t_exp,
		// 	"nbf" => $t_nbf,
		// 	"aud" => $t_aud
		// ]);
		var_dump($settings);
		return TRUE;
	}
	private static function verify_hash($algo, &$settings, &$token, &$token_string) {
		$invalid = ["Invalid authorization token", JWT::ERR_AUTH];
		switch($algo) {
			case "HS256":
				$signature = JWT::get_val($token, "signature");
				if($signature === NULL) {
					return $invalid;
				}
				$key = JWT::get_val($settings, "keys", "HS256");
				if(is_array($key)) {
					$kid = JWT::get_val($token, "payload", "kid");
					if($kid !== NULL && is_numeric($kid)) {
						$key = JWT::get_val($key, $kid);
					}
				}
				if($key === NULL) {
					return $invalid;
				}
				$header_string = JWT::get_val($token_string, "header");
				$payload_string = JWT::get_val($token_string, "payload");
				if($header_string === NULL || $payload_string === NULL) {
					return $invalid;
				}
				$verify = hash_equals(hash_hmac("sha256", "{$header_string}.{$payload_string}", $key, TRUE), $signature);
				if($verify === FALSE) {
					return $invalid;
				}
				break;
			default:
				return ["Authorization JWT algorithm used is not supported", JWT::ERR_AUTH];
				break;
		}
		return TRUE;
	}
	public function validate_token(array $settings = []) {
		$this->load_token();
		if($this->error !== NULL) {
			return FALSE;
		}
		$this->load_settings();
		if($this->error !== NULL) {
			return FALSE;
		}
		$settings = array_merge($this->settings, $settings);
		if(
			JWT::array_keys_missing($this->token["header"], "alg", "typ")
			|| ($this->token["header"]["typ"] !== "JWT")
		) {
			$this->error = ["Authorization token is not in JWT format", JWT::ERR_AUTH];
			return FALSE;
		}
		$algo = JWT::get_val($this->token, "header", "alg");
		$verify = JWT::verify_hash($algo, $settings, $this->token, $this->token_string);
		if($verify !== TRUE) {
			$this->error = $verify;
			return FALSE;
		}
		$verify = JWT::verify_standard_claims($settings, $this->token);
		if($verify !== TRUE) {
			$this->error = $verify;
			return FALSE;
		}
		return TRUE;
	}
	public function generate_token(array $payload = [], $algo = "HS256", $key = 0) {
		$this->load_settings();
		
		$p = [];
		$p["iat"] = time();
		$p["nbf"] = $p["iat"];
		
		$exp = JWT::get_val($this->settings, "exp");
		$exp = ($exp === NULL) ? 1200 : intval($exp);
		$p["exp"] = $p["iat"] + $exp;

		$iss = JWT::get_val($this->settings, "iss");
		if($iss !== NULL) {
			$p["iss"] = $iss;
		}

		$aud = JWT::get_val($this->settings, "aud");
		if($aud !== NULL) {
			$p["aud"] = $aud;
		}

		$this->token = [];
		$this->token["payload"] = array_merge($p, $payload);
		$this->token["header"] = ["alg" => $algo, "typ" => "JWT"];
		$this->token_string = [];
		$this->token_string["header"] = JWT::base64url_encode(json_encode($this->token["header"]));
		$this->token_string["payload"] = JWT::base64url_encode(json_encode($this->token["payload"]));
		$this->token["signature"] = hash_hmac("sha256", "{$this->token_string["header"]}.{$this->token_string["payload"]}", JWT::get_val($this->settings, "keys", "HS256", 0), TRUE);
		$this->token_string["signature"] = JWT::base64url_encode($this->token["signature"]);

		return "{$this->token_string["header"]}.{$this->token_string["payload"]}.{$this->token_string["signature"]}";
	}
}

$jwt = new JWT();
var_dump($jwt->validate_token());

// var_dump($jwt->generate_token());

var_dump($jwt);
?>