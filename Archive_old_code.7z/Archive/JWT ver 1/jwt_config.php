<?php
return [
	"keys" => [
		"HS256" => [
			'C*F-JaNdRgUkXp2s5v8y/B?D(G+KbPeS',
			'!z$C&F)J@NcRfUjXn2r5u8x/A?D*G-Ka'
		]
	],
	"iss" => "token.test.com",
	"aud" => "app.token.com",
	/* exp is in seconds */
	"exp" => 600,
	/* leeway is in seconds */
	"leeway" => 30
];
?>